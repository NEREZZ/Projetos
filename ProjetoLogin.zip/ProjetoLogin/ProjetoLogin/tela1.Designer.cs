﻿namespace ProjetoLogin
{
    partial class tela1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(tela1));
            this.painel = new System.Windows.Forms.Panel();
            this.Acessar = new System.Windows.Forms.Button();
            this.caixaSenha = new System.Windows.Forms.TextBox();
            this.caixaUser = new System.Windows.Forms.TextBox();
            this.painel.SuspendLayout();
            this.SuspendLayout();
            // 
            // painel
            // 
            this.painel.BackColor = System.Drawing.Color.Transparent;
            this.painel.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("painel.BackgroundImage")));
            this.painel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.painel.Controls.Add(this.Acessar);
            this.painel.Controls.Add(this.caixaSenha);
            this.painel.Controls.Add(this.caixaUser);
            this.painel.Location = new System.Drawing.Point(204, 139);
            this.painel.Name = "painel";
            this.painel.Size = new System.Drawing.Size(436, 397);
            this.painel.TabIndex = 0;
            // 
            // Acessar
            // 
            this.Acessar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Acessar.BackgroundImage")));
            this.Acessar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Acessar.FlatAppearance.BorderSize = 0;
            this.Acessar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.Acessar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.Acessar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Acessar.Font = new System.Drawing.Font("Palatino Linotype", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.World, ((byte)(0)));
            this.Acessar.Location = new System.Drawing.Point(103, 267);
            this.Acessar.Name = "Acessar";
            this.Acessar.Size = new System.Drawing.Size(269, 80);
            this.Acessar.TabIndex = 2;
            this.Acessar.Text = "ACESSAR";
            this.Acessar.UseVisualStyleBackColor = true;
            this.Acessar.Click += new System.EventHandler(this.Acessar_Click);
            // 
            // caixaSenha
            // 
            this.caixaSenha.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.caixaSenha.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.caixaSenha.Location = new System.Drawing.Point(115, 155);
            this.caixaSenha.Multiline = true;
            this.caixaSenha.Name = "caixaSenha";
            this.caixaSenha.PasswordChar = '*';
            this.caixaSenha.Size = new System.Drawing.Size(238, 51);
            this.caixaSenha.TabIndex = 1;
            // 
            // caixaUser
            // 
            this.caixaUser.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.caixaUser.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.caixaUser.Location = new System.Drawing.Point(115, 63);
            this.caixaUser.Multiline = true;
            this.caixaUser.Name = "caixaUser";
            this.caixaUser.Size = new System.Drawing.Size(246, 41);
            this.caixaUser.TabIndex = 0;
            // 
            // tela1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(958, 603);
            this.Controls.Add(this.painel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "tela1";
            this.Text = "Login";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.tela1_Load);
            this.painel.ResumeLayout(false);
            this.painel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel painel;
        private System.Windows.Forms.TextBox caixaSenha;
        private System.Windows.Forms.TextBox caixaUser;
        private System.Windows.Forms.Button Acessar;
    }
}

